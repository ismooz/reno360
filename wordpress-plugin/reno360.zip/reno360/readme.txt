=== Reno360 — Devis travaux et CRM ===
Contributors: reno360
Tags: devis, travaux, artisans, crm, formulaire
Requires at least: 6.2
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Plateforme de demandes de devis travaux : recherche intelligente, formulaire guidé, espace client, liens artisans et back-office complet.

== Description ==

* Recherche par mots-clés tolérante aux fautes, aux pluriels et aux accents, avec suggestions instantanées.
* 60 types de travaux et 1 555 mots-clés prêts à l'emploi. Ajout, modification, suppression, import et export CSV.
* Formulaire de demande en 5 étapes : questions propres à chaque travail, photos, brouillon conservé.
* Espace client sans mot de passe (lien par e-mail) : suivi, messages, comparaison et acceptation des devis.
* Lien sécurisé pour chaque artisan : dépôt du devis PDF ou refus.
* Back-office : tableau de bord, demandes en liste ou en Kanban, historique, tâches, artisans, devis, clients, analyse des recherches.
* E-mails modifiables et automatisations (relances, rappels, demande d'avis, conservation nLPD).
* 5 palettes de couleurs, en-tête et pied de page complets, demande rapide en 3 étapes.
* Compatible Divi 5 et thèmes à blocs : gabarit pleine largeur et 18 shortcodes.

== Installation ==

1. Extensions → Ajouter → Téléverser une extension → reno360.zip → Activer.
2. Reno360 → Réglages : coordonnées, logo, couleur, e-mails de l'équipe.
3. Réglages → Pages et intégration Divi : définir l'accueil.
4. Configurer l'envoi d'e-mails avec une extension SMTP.

== Frequently Asked Questions ==

= Comment ajouter un mot-clé ? =

Reno360 → Travaux et mots-clés → ouvrir le travail → taper le mot-clé puis Entrée → Enregistrer. Vous pouvez aussi passer par Reno360 → Recherches → « Recherches sans résultat » → Ajouter.

= Mes données sont-elles supprimées si je désactive l'extension ? =

Non. Elles sont supprimées à la désinstallation seulement si l'option est cochée dans Réglages → Données.

== Changelog ==

= 1.1.0 =
* Nouvelle identité visuelle reprise de la maquette : typographies Schibsted Grotesk, Instrument Serif et IBM Plex Mono, 5 palettes de couleurs au choix.
* En-tête et pied de page Reno360 (bandeau, menu « Travaux » déroulant, menu mobile), automatiques avec un thème à blocs, par shortcode avec Divi.
* Demande rapide en 3 étapes dans une fenêtre, depuis tous les boutons « Demander un devis ».
* Accueil : catalogue intégré par catégories avec recherche, simulateur de subventions, FAQ en accordéon.

= 1.0.3 =
* Thèmes à blocs : les pages Reno360 reprennent l'en-tête et le pied de page du modèle réellement utilisé par le thème (logo, menu, variantes d'en-tête et blocs ajoutés dans l'éditeur de site).

= 1.0.2 =
* Les pages Reno360 s'affichent toujours en pleine largeur et sans titre, y compris la page d'accueil des thèmes à blocs (Twenty Twenty-Five…) où le modèle ne peut pas être choisi.

= 1.0.1 =
* Aucun numéro de téléphone affiché par défaut ; tous les textes s'adaptent quand le champ est vide.

= 1.0.0 =
* Première version.
